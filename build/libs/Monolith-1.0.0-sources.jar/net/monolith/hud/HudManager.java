package net.monolith.hud;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.monolith.module.ModuleManager;
import net.monolith.utils.RenderUtils;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HudManager {
    public static final List<HudElement> elements = new ArrayList<>();

    public static void init() {
        elements.add(new HudElement(10, 10, 140, 16) {
            @Override
            public void render(class_332 context, float tickDelta) {
                class_310 mc = class_310.method_1551();
                String text = "Monolith | " + (mc.method_1548() != null ? mc.method_1548().method_1676() : "Player") + " | " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + " | " + mc.method_47599() + " FPS";
                this.width = mc.field_1772.method_1727(text) + 12;
                RenderUtils.drawRoundedRect(context, x, y, width, height, 4, 0x990A0A0A);
                context.method_25296(x + 2, y + 1, x + width - 2, y + 2, 0xFF8E2DE2, 0xFF4A00E0);
                context.method_51433(mc.field_1772, text, x + 6, y + 5, 0xFFFFFF, false);
            }
        });
        elements.add(new PotionHudElement(10, 40));
    }

    public static void render(class_332 context, float tickDelta) {
        if (ModuleManager.getModule("HUD") != null && !ModuleManager.getModule("HUD").enabled) return;
        class_310 mc = class_310.method_1551();
        boolean inChat = mc.field_1755 instanceof class_408;

        for (HudElement el : elements) {
            if (inChat) {
                int mouseX = (int)(mc.field_1729.method_1603() * mc.method_22683().method_4486() / mc.method_22683().method_4480());
                int mouseY = (int)(mc.field_1729.method_1604() * mc.method_22683().method_4502() / mc.method_22683().method_4507());
                el.renderEditMode(context, mouseX, mouseY);
            } else el.render(context, tickDelta);
        }
    }

    public static boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (ModuleManager.getModule("HUD") != null && !ModuleManager.getModule("HUD").enabled) return false;
        for (HudElement el : elements) if (el.mouseClicked(mouseX, mouseY, button)) return true;
        return false;
    }
    public static void mouseReleased(int button) { for (HudElement el : elements) el.mouseReleased(button); }
}
