package net.monolith.hud;

import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.monolith.utils.RenderUtils;
import java.util.Collection;

public class PotionHudElement extends HudElement {
    private float heightAnim = 0;

    public PotionHudElement(int x, int y) { super(x, y, 130, 20); }

    @Override
    public void render(class_332 context, float tickDelta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        Collection<class_1293> effects = mc.field_1724.method_6026();
        boolean isChatOpen = mc.field_1755 instanceof net.minecraft.class_408;
        float targetHeight = effects.isEmpty() ? (isChatOpen ? 22 : 0) : 22 + (effects.size() * 16);

        heightAnim = RenderUtils.lerp(heightAnim, targetHeight, 0.15f * tickDelta);
        if (heightAnim < 1) return;

        int currentHeight = (int) heightAnim;
        this.height = currentHeight;
        
        RenderUtils.drawRoundedRect(context, x, y, width, currentHeight, 5, 0xB30A0A0D);
        if (heightAnim > 15) {
            context.method_51433(mc.field_1772, "Potions", x + width / 2 - mc.field_1772.method_1727("Potions") / 2, y + 6, 0xAA88CC, false);
            context.method_25294(x + 5, y + 18, x + width - 5, y + 19, 0x33FFFFFF);
        }

        int eY = y + 22;
        for (class_1293 effect : effects) {
            if (eY + 14 > y + currentHeight) break;
            
            String name = effect.method_5579().comp_349().method_5560().getString();
            int amp = effect.method_5578();
            if (amp > 0) name += " " + (amp + 1);

            int sec = effect.method_5584() / 20;
            String durationStr = String.format("%02d:%02d", sec / 60, sec % 60);

            context.method_51433(mc.field_1772, name, x + 8, eY + 2, 0xFFFFFF, false);
            context.method_51433(mc.field_1772, durationStr, x + width - 8 - mc.field_1772.method_1727(durationStr), eY + 2, 0xAAAAAA, false);
            eY += 16;
        }
    }
}
