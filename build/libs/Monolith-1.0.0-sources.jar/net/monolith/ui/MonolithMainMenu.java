package net.monolith.ui;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.monolith.utils.RenderUtils;

import java.util.ArrayList;
import java.util.List;

public class MonolithMainMenu extends class_437 {
    private static final class_2960 LOGO_TEXTURE = class_2960.method_60655("monolith", "textures/ui/logo.png");
    private final List<MenuButton> buttons = new ArrayList<>();
    private final int ACCENT = 0xFF00E5FF;
    private float openAnim = 0f;

    public MonolithMainMenu() {
        super(class_2561.method_43470("Monolith Main Menu"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        buttons.clear();
        
        int btnWidth = 200;
        int btnHeight = 35;
        
        int startX = this.field_22789 - btnWidth - 25;
        int startY = (this.field_22790 - (4 * (btnHeight + 15))) / 2;

        // ИСПРАВЛЕНИЕ: Перевели на английский, чтобы шрифт Intel Mono работал без квадратиков
        buttons.add(new MenuButton("Singleplayer", startX, startY, btnWidth, btnHeight, () -> {
            this.field_22787.method_1507(new class_526(this));
        }));
        buttons.add(new MenuButton("Multiplayer", startX, startY + 50, btnWidth, btnHeight, () -> {
            this.field_22787.method_1507(new class_500(this));
        }));
        buttons.add(new MenuButton("Settings", startX, startY + 100, btnWidth, btnHeight, () -> {
            this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690));
        }));
        buttons.add(new MenuButton("Quit", startX, startY + 150, btnWidth, btnHeight, () -> {
            this.field_22787.method_1592();
        }));
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xFF050508, 0xFF000000);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        openAnim = RenderUtils.lerp(openAnim, 1f, 0.1f * delta);

        // --- Логотип ---
        int logoSize = (int)(320 * openAnim);
        int logoX = (this.field_22789 / 2) - 200 - (logoSize / 2);
        int logoY = (this.field_22790 / 2) - (logoSize / 2);
        
        context.method_51448().method_22903();
        float breathe = (float)Math.sin(System.currentTimeMillis() / 1000.0) * 8;
        context.method_25290(net.minecraft.class_1921::method_62277, LOGO_TEXTURE, logoX, (int)(logoY + breathe), 0.0f, 0.0f, logoSize, logoSize, logoSize, logoSize);
        
        // --- Боковая панель ---
        int panelWidth = 260;
        int panelX = this.field_22789 - panelWidth;
        RenderUtils.drawRect(context, panelX, 0, panelWidth, this.field_22790, 0x880A0A0C);

        // --- Кнопки ---
        for (MenuButton btn : buttons) {
            btn.render(context, mouseX, mouseY, delta);
        }
        
        RenderUtils.drawText(context, field_22793, "Monolith Client v1.0", 10, this.field_22790 - 15, 0x33FFFFFF, false);

        context.method_51448().method_22909();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        for (MenuButton btn : buttons) {
            if (btn.mouseClicked(mouseX, mouseY, button)) return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private class MenuButton {
        String textString;
        int x, y, width, height;
        Runnable action;
        float hoverAnim = 0f;

        public MenuButton(String text, int x, int y, int width, int height, Runnable action) {
            this.textString = text; this.x = x; this.y = y; this.width = width; this.height = height; this.action = action;
        }

        public void render(class_332 context, int mouseX, int mouseY, float delta) {
            boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
            hoverAnim = RenderUtils.lerp(hoverAnim, hovered ? 1f : 0f, 0.2f * delta);

            int bg = RenderUtils.lerpColor(0xFF15151A, 0xFF222228, hoverAnim);
            RenderUtils.drawRoundedRect(context, x, y, width, height, 6, bg);
            
            if (hoverAnim > 0.05f) {
                RenderUtils.drawRoundedRect(context, x, y + 6, 3, height - 12, 1, ACCENT);
            }

            int textColor = RenderUtils.lerpColor(0xFFAAAAAA, 0xFFFFFFFF, hoverAnim);
            int textOffset = (int)(8 * hoverAnim);
            
            // ИСПРАВЛЕНИЕ: Вызываем отрисовку строго через наш RenderUtils, чтобы наложился шрифт
            RenderUtils.drawText(context, field_22793, textString, x + 20 + textOffset, y + (height - 8) / 2, textColor, false);
        }

        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height && button == 0) {
                action.run();
                return true;
            }
            return false;
        }
    }
}
