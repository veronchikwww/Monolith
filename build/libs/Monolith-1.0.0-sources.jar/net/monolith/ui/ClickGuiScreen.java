package net.monolith.ui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.monolith.module.Module;
import net.monolith.module.ModuleManager;
import net.monolith.utils.RenderUtils;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends class_437 {
    private final List<Panel> panels = new ArrayList<>();
    private boolean initialized = false;
    private float openAnim = 0f;
    private final int ACCENT = 0xFF00E5FF;

    public ClickGuiScreen() { super(class_2561.method_43470("Monolith DropDown")); }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (!initialized) {
            String[] categories = {"Combat", "Movement", "Visuals", "Player", "Misc"};
            int panelWidth = 120; int spacing = 15;
            int totalWidth = (categories.length * panelWidth) + ((categories.length - 1) * spacing);
            int startX = (this.field_22789 - totalWidth) / 2;
            for (String category : categories) {
                panels.add(new Panel(category, startX, 40, panelWidth));
                startX += panelWidth + spacing;
            }
            initialized = true;
        }
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0x88000000, 0xBB000000);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        openAnim = RenderUtils.lerp(openAnim, 1f, 0.15f * delta);
        
        context.method_51448().method_22903();
        context.method_51448().method_46416(this.field_22789 / 2f, this.field_22790 / 2f, 0);
        context.method_51448().method_22905(0.85f + (0.15f * openAnim), 0.85f + (0.15f * openAnim), 1f);
        context.method_51448().method_46416(-this.field_22789 / 2f, -this.field_22790 / 2f, 0);

        for (Panel panel : panels) panel.render(context, mouseX, mouseY, delta);
        context.method_51448().method_22909();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        for (Panel panel : panels) if (panel.mouseClicked(mouseX, mouseY, button)) return true;
        return super.method_25402(mouseX, mouseY, button);
    }
    @Override public boolean method_25421() { return false; }

    private class Panel {
        public String name; public int x, y, width;
        public Panel(String name, int x, int y, int width) { this.name = name; this.x = x; this.y = y; this.width = width; }
        
        public void render(class_332 context, int mouseX, int mouseY, float delta) {
            List<Module> mods = ModuleManager.getModulesByCategory(name);
            int modsHeight = 0;
            for (Module mod : mods) {
                modsHeight += 20;
                mod.expandAnim = RenderUtils.lerp(mod.expandAnim, (mod.expanded && !mod.modes.isEmpty()) ? 1f : 0f, 0.2f * delta);
                modsHeight += (int)(mod.modes.size() * 20 * mod.expandAnim); 
            }
            
            int totalHeight = 26 + modsHeight + 4;
            RenderUtils.drawRoundedRect(context, x - 2, y - 2, width + 4, totalHeight + 4, 8, 0x33000000);
            RenderUtils.drawRoundedRect(context, x, y, width, totalHeight, 6, 0xFA08080A);
            
            RenderUtils.drawCenteredText(context, field_22793, name, x + width / 2, y + 9, 0xFFFFFF, true);
            RenderUtils.drawRect(context, x + 10, y + 24, width - 20, 1, 0x33FFFFFF);

            int currentY = y + 28;
            for (Module mod : mods) {
                boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= currentY && mouseY <= currentY + 20;
                mod.hoverAnim = RenderUtils.lerp(mod.hoverAnim, hovered ? 1f : 0f, 0.2f * delta);
                mod.toggleAnim = RenderUtils.lerp(mod.toggleAnim, mod.enabled ? 1f : 0f, 0.2f * delta);
                
                if (mod.hoverAnim > 0.05f || mod.toggleAnim > 0.05f) {
                    int bgAlpha = (int)(25 * Math.max(mod.hoverAnim, mod.toggleAnim));
                    RenderUtils.drawRoundedRect(context, x + 4, currentY, width - 8, 20, 4, (bgAlpha << 24) | (ACCENT & 0xFFFFFF));
                }
                
                if (mod.toggleAnim > 0.05f) {
                    RenderUtils.drawRoundedRect(context, x + 4, currentY + 4, 2, 12, 1, ACCENT);
                }
                
                int textColor = RenderUtils.lerpColor(0xFFAAAAAA, 0xFFFFFFFF, Math.max(mod.toggleAnim, mod.hoverAnim));
                RenderUtils.drawText(context, field_22793, mod.name, x + 14, currentY + 6, textColor, false);
                
                if (!mod.modes.isEmpty()) {
                    RenderUtils.drawText(context, field_22793, mod.expanded ? "-" : "+", x + width - 15, currentY + 6, 0x666666, false);
                }
                
                currentY += 20;

                if (mod.expandAnim > 0.01f) {
                    int modeHeight = (int)(mod.modes.size() * 20 * mod.expandAnim);
                    RenderUtils.drawRect(context, x + 14, currentY, 1, Math.max(0, modeHeight - 2), ACCENT); 
                    
                    context.method_44379(x, currentY, x + width, currentY + modeHeight);
                    int mY = currentY;
                    int textAlpha = (int)(255 * Math.min(1f, mod.expandAnim * 1.5f)); 
                    
                    for (String mode : mod.modes) {
                        boolean isCurrent = mod.currentMode.equals(mode);
                        int modeColor = isCurrent ? ACCENT : 0xFF777777;
                        modeColor = (modeColor & 0x00FFFFFF) | (textAlpha << 24); 
                        
                        RenderUtils.drawText(context, field_22793, mode, x + 20, mY + 6, modeColor, false);
                        mY += 20;
                    }
                    context.method_44380();
                    currentY += modeHeight;
                }
            }
        }

        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            int currentY = y + 28;
            for (Module mod : ModuleManager.getModulesByCategory(name)) {
                if (mouseX >= x && mouseX <= x + width && mouseY >= currentY && mouseY <= currentY + 20) {
                    if (button == 0) { mod.toggle(); return true; } 
                    else if (button == 1 && !mod.modes.isEmpty()) { mod.expanded = !mod.expanded; return true; }
                }
                currentY += 20;
                if (mod.expanded && !mod.modes.isEmpty()) {
                    for (String mode : mod.modes) {
                        if (mouseX >= x + 10 && mouseX <= x + width && mouseY >= currentY && mouseY <= currentY + 20 && button == 0) { 
                            mod.currentMode = mode; 
                            if (mod.name.equals("ClickGui")) {
                                if (mode.equals("Cards")) class_310.method_1551().method_1507(new CardsGuiScreen());
                                else if (mode.equals("CsGui")) class_310.method_1551().method_1507(new CsGuiScreen());
                            }
                            return true; 
                        }
                        currentY += 20;
                    }
                }
            }
            return false;
        }
    }
}
