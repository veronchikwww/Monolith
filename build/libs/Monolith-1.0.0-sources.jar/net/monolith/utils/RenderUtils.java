package net.monolith.utils;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class RenderUtils {
    // Указываем ID нашего кастомного шрифта
    public static final class_2960 CUSTOM_FONT = class_2960.method_60655("monolith", "main");

    // Обертка для создания текста с нашим шрифтом
    public static class_2561 getCustomText(String text) {
        return class_2561.method_43470(text).method_10862(class_2583.field_24360.method_27704(CUSTOM_FONT));
    }

    // Отрисовка кастомного текста
    public static void drawText(class_332 context, class_327 renderer, String text, int x, int y, int color, boolean shadow) {
        context.method_51439(renderer, getCustomText(text), x, y, color, shadow);
    }

    // Отрисовка кастомного текста по центру
    public static void drawCenteredText(class_332 context, class_327 renderer, String text, int centerX, int y, int color, boolean shadow) {
        class_2561 styled = getCustomText(text);
        context.method_51439(renderer, styled, centerX - renderer.method_27525(styled) / 2, y, color, shadow);
    }

    // Получение ширины кастомного текста
    public static int getTextWidth(class_327 renderer, String text) {
        return renderer.method_27525(getCustomText(text));
    }

    public static void drawRect(class_332 context, int x, int y, int width, int height, int color) {
        context.method_25294(x, y, x + width, y + height, color);
    }

    public static void drawRoundedRect(class_332 context, int x, int y, int width, int height, int radius, int color) {
        context.method_25294(x + radius, y, x + width - radius, y + height, color);
        context.method_25294(x, y + radius, x + radius, y + height - radius, color);
        context.method_25294(x + width - radius, y + radius, x + width, y + height - radius, color);
        
        context.method_25294(x + 1, y + 1, x + radius, y + radius, color);
        context.method_25294(x + width - radius, y + 1, x + width - 1, y + radius, color);
        context.method_25294(x + 1, y + height - radius, x + radius, y + height - 1, color);
        context.method_25294(x + width - radius, y + height - radius, x + width - 1, y + height - 1, color);
    }

    public static float lerp(float start, float end, float delta) {
        return start + (end - start) * delta;
    }

    public static int lerpColor(int from, int to, float delta) {
        int r1 = (from >> 16) & 0xFF; int g1 = (from >> 8) & 0xFF; int b1 = from & 0xFF; int a1 = (from >> 24) & 0xFF;
        int r2 = (to >> 16) & 0xFF;   int g2 = (to >> 8) & 0xFF;   int b2 = to & 0xFF;   int a2 = (to >> 24) & 0xFF;
        int r = (int) (r1 + (r2 - r1) * delta); int g = (int) (g1 + (g2 - g1) * delta);
        int b = (int) (b1 + (b2 - b1) * delta); int a = (int) (a1 + (a2 - a1) * delta);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
