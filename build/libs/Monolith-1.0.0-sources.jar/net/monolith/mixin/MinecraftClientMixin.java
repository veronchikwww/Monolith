package net.monolith.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.monolith.ui.MonolithMainMenu;

@Mixin(class_310.class)
public class MinecraftClientMixin {
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void onSetScreen(class_437 screen, CallbackInfo ci) {
        // Перехватываем открытие стандартного меню
        if (screen != null && screen.getClass() == class_442.class) {
            ci.cancel();
            ((class_310)(Object)this).method_1507(new MonolithMainMenu());
        }
    }
}
