package net.monolith;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.monolith.ui.ClickGuiScreen;
import net.monolith.ui.CardsGuiScreen;
import net.monolith.ui.CsGuiScreen;
import net.monolith.module.Module;
import net.monolith.module.ModuleManager;
import net.monolith.hud.HudManager;

public class Monolith implements ClientModInitializer {
    public static final String MOD_ID = "monolith";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static class_304 guiKeyBinding;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        HudManager.init();

        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.monolith.opengui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.monolith.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKeyBinding.method_1436()) {
                if (client.field_1755 == null) {
                    Module cg = ModuleManager.getModule("ClickGui");
                    if (cg != null) {
                        switch (cg.currentMode) {
                            case "Cards": client.method_1507(new CardsGuiScreen()); break;
                            case "CsGui": client.method_1507(new CsGuiScreen()); break;
                            case "DropDown": default: client.method_1507(new ClickGuiScreen()); break;
                        }
                    } else {
                        client.method_1507(new CsGuiScreen());
                    }
                }
            }
        });

        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            HudManager.render(context, tickDelta.method_60637(true));
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_408) {
                ScreenMouseEvents.allowMouseClick(screen).register((screen1, mouseX, mouseY, button) -> {
                    if (HudManager.mouseClicked(mouseX, mouseY, button)) return false;
                    return true;
                });
                ScreenMouseEvents.allowMouseRelease(screen).register((screen1, mouseX, mouseY, button) -> {
                    HudManager.mouseReleased(button);
                    return true;
                });
            }
        });
    }
}
